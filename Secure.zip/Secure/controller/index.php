<!DOCTYPE html>
<html>
	<head>
		<title>Grades Management System</title>
		<link href="simpsons.css" type="text/css" rel="stylesheet" />
	</head>

	<body>
		<h1>Vulnerable Grades Management System</h1>

		<ul>
			<li><a href="register.php">Sign Up - Student</a></li>
			<li><a href="login.php">Log In - Student</a></li>
			<li><a href="login_teacher.php">Log In - Teacher</a></li>
		</ul>
	</body>
</html>